// App名称
String appName = "飞镖影视";

// web hostUrl localhost cms port http://10.0.2.2:9999
String hostUrl = "http://10.0.2.2:9999";

// app cur uniqueKey => uuid
String appUniqueKey = "d07d4da9-d535-49c9-8253-8e9a1fcec99a";
