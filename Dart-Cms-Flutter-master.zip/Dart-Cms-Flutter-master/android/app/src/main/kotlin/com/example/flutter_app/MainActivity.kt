package com.example.dart_movie

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
